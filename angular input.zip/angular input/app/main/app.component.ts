import { Component } from '@angular/core';
import { LoginService } from '../login/login.service';

@Component({
  selector: 'my-app',
  templateUrl: "../app/main/app.component.html",
  styleUrls: ["../app/main/app.component.css"]
})

export class AppComponent  {
public name:any; 
	constructor(private loginservice: LoginService){
		this.loginservice=loginservice;
	}
	ngDoCheck()
	{
		this.name=this.loginservice.getData();
	}
}
