import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpModule }    from '@angular/http';
import { AppComponent }  from './main/app.component';
import { LoginComponent }   from './login/login.component';
import { LoginService } from './login/login.service';
import { routing, appRoutingProviders } from './app.route'; 

@NgModule({
  imports:      [ BrowserModule,
  					 routing,
                     HttpModule ],
  declarations: [ AppComponent,
                     LoginComponent ],
  providers:      [ LoginService,
                  ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
