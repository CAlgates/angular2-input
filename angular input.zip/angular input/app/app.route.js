"use strict";
var router_1 = require('@angular/router');
var app_component_1 = require('./main/app.component');
var login_component_1 = require('./login/login.component');
exports.routes = [
    { path: '', redirectTo: 'login-component', pathMatch: 'full' },
    { path: 'app-component', component: app_component_1.AppComponent },
    { path: 'login-component', component: login_component_1.LoginComponent },
];
exports.appRoutingProviders = [];
exports.routing = router_1.RouterModule.forRoot(exports.routes);
//# sourceMappingURL=app.route.js.map