import { Routes, RouterModule } from '@angular/router';
import { AppComponent }  from './main/app.component';
import { LoginComponent } from './login/login.component';



export const routes: Routes = [
  { path: '', redirectTo: 'login-component', pathMatch: 'full' },
  { path:'app-component', component:AppComponent},
  { path: 'login-component', component: LoginComponent },

                              ];

export const appRoutingProviders: any[] = [

];

export const routing = RouterModule.forRoot(routes); 