import { Component } from '@angular/core';
import { LoginService } from './login.service';

@Component({
  selector: 'my-app',
  templateUrl: "../app/login/login.component.html",
  styleUrls: ["../app/login/login.component.css"]
})

export class LoginComponent  {
	constructor(private loginservice: LoginService){
		this.loginservice=loginservice;
	}
	change(name)
	{
		console.log("name",name);
		this.loginservice.saveData(name);
	}
 }