import {Component, Injectable,Input,Output,EventEmitter} from '@angular/core';
import { Http, Response } from '@angular/http';

export interface myData {
name:string;
}
@Injectable()
export class LoginService {
sharingData: myData={name:""};
constructor( private http:Http){
}

saveData(a){
this.sharingData.name=a; 
console.log(this.sharingData.name);
}
getData()
{
console.log(this.sharingData.name);
return this.sharingData.name;
}
}  